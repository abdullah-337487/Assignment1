﻿
//using System;
//using System.Numerics;

//namespace MyApp
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            pick();
//        }
//        static void pick()
//        {
//            string[] strArr = { "00011", "01010" };
//            string str1 = strArr[0];
//            string str2 = strArr[1];
//            char[] result = new char[str1.Length];


//            for (int i = 0; i < str1.Length; i++)
//            {
//                if (str1[i] == '1' || str2[i]=='1')
//                {
//                    result[i] = '1';
//                }
//                else
//                {
//                    result[i]= '0';
//                }
//            }
//            Console.WriteLine(result);
//        }
//    }
//}




//using System;
//using System.Numerics;

//namespace MyApp
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            pick();
//        }
//        static void pick()
//        {
//            string str = "Hello6 9World 2, Nic8e D7ay!";
//            int sum = 0;
//            int lettercount = 0;
//            foreach (char c in str)
//            {
//                if (char.IsDigit(c))
//                {
//                    sum += int.Parse(c.ToString());
//                }
//                if (char.IsLetter(c))
//                {
//                    lettercount++;
//                }
//            }
//            double div = (double)sum / lettercount;
//            //Console.WriteLine(div);
//            int result = (int)Math.Round(div);
//            // if(result > 0) {
//            Console.WriteLine(result);
//        }
//    }
//}




//using System;

//namespace MyApp
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            prime();
//        }

//        static void prime()
//        {
//            int num = 1709; // Change this to test with different numbers
//            string result = "";

//            if (num <= 1)
//            {
//                result = "false";
//            }
//            else if (num == 2)
//            {
//                result = "true";
//            }
//            else
//            {
//                result = "true"; // Assume the number is prime initially
//                for (int i = 2; i <= Math.Sqrt(num); i++)
//                {
//                    if (num % i == 0)
//                    {
//                        result = "false";
//                        break; // No need to check further if a divisor is found
//                    }
//                }
//            }

//            Console.WriteLine(result);
//        }
//    }
//}


using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            prime();
        }

        static void prime()
        {
            int[] arr = { 1,2,2,4,9,8,7,6 };
            int longest = 1;
            int current = 1;
            Array.Sort(arr);
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] == arr[i-1]+1)
                {
                    current++;
                }
                else if (arr[i] != arr[i - 1]+1)
                {
                    longest=Math.Max(longest,current);
                    current = 1;
                }
            }
            longest = Math.Max(longest, current);
            Console.WriteLine(longest);
        }
    }
}
