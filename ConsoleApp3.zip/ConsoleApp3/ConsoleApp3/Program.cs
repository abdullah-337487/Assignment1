﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            area();
        }

        static void area()
        {

            string str = "passWord123!!!!";
            char[] chars = str.ToCharArray();
            //Console.WriteLine(chars[0]);

            string result = "false";
            foreach (char c in str)
            {
                if (str.Length! > 7 && str.Length! < 31)
                {
                    if (c! >= 33 && c! <= 47 && c! >= 58 && c! <= 64 && c! >= 92 && c! <= 96 && c! >= 123 && c! <= 126 || c! >= 48 && c! <= 57 || c! >= 65 && c! <= 90 || c! >= 91 && c! <= 96 || c! >= 97 && c! <= 122 || c! >= 123 && c! <= 126)
                    {
                        result = "false";
                    }

                    else
                    {
                        result = "true";
                    }
                }
                else
                {
                    result = "false";
                }

            }

            for (int i = 0; i < str.Length; i++)
            {
                //if (chars[i] == 'p' || chars[i] == 'P' && chars[i + 1] == 'a' || chars[i + 1] == 'A' && chars[i + 2] == 's' || chars[i + 2] == 'S' && chars[i + 3] == 's' || chars[i + 3] == 'S' && chars[i + 4] == 'w' || chars[i + 4] == 'W' && chars[i + 5] == 'o' || chars[i + 5] == 'O' && chars[i + 6] == 'r' || chars[i + 6] == 'R' && chars[i + 7] == 'd' || chars[i + 7] == 'D')
                // {
                //    result = "faslse";
                //}
                //if (chars.Length > 23 && chars.Length < 31 && chars[23] == 'p' || chars[30] == 'P'&& chars[23] == 'd' || chars[30] == 'D')
                // {

                //    result = "false";
                // }
                if (chars[0] == 'p' || chars[0] == 'P' && chars[1] == 'a' || chars[1] == 'A' && chars[2] == 's' || chars[2] == 'S' && chars[3] == 's' || chars[3] == 'S' && chars[4] == 'w' || chars[4] == 'W' && chars[5] == 'o' || chars[5] == 'O' && chars[6] == 'r' || chars[6] == 'R' && chars[7] == 'd' || chars[7] == 'D')
                {
                    result = "false";
                }
                else
                {
                    result = "true";
                }
            }

            Console.WriteLine(result);

        }
    }
}


//using System;
//using static System.Runtime.InteropServices.JavaScript.JSType;

//namespace MyApp
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            area();
//        }

//        static void area()
//        {
//            int num = 134;
//            List<int> list = new List<int>(num);

//            Console.WriteLine(list);
//        }
//    }
//}



//using System;
//using static System.Runtime.InteropServices.JavaScript.JSType;

//namespace MyApp
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            area();
//        }

//        static void area()
//        {
//            string str = "Hello";
//            int num = 4;
//            string result = "";
//            if (num == 0)
//            {
//                Console.WriteLine(str);
//            }
//            else if (num > 0)
//            {
//                foreach (char c in str)
//                {
//                    int x = (int)c + num;
//                    char y = (char)x;
//                    result += char.ToString(y);

//                }
//                Console.WriteLine(result);
//            }


//        }
//    }
//}


//using System;
//using static System.Runtime.InteropServices.JavaScript.JSType;

//namespace MyApp
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            area();
//        }

//        static void area()
//        {


//            Console.WriteLine(result);

//        }
//    }
//}
